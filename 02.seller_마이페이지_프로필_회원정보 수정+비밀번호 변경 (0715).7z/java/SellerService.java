package com.spring.seller;



public interface SellerService {
	SellerVO selectOneById(String id);
	boolean duplicateCheck(String id);
	void RegisterSellerAccout(SellerVO seller);

	int DeleteSellerAccount(String id);
	void UpdateProfileImg(SellerVO account);

============================== [ 기석 작업 시작 ] ==============================

	int UpdateSellerAccount(SellerVO seller);

============================== [ 기석 작업 끝 ] ==============================



}
