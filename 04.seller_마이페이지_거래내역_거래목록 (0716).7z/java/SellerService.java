package com.spring.seller;

import java.util.List;

import com.spring.order.OrderRecordVO;

public interface SellerService {
	SellerVO selectOneById(String id);
	boolean duplicateCheck(String id);
	void RegisterSellerAccout(SellerVO seller);
	int UpdateSellerAccount(SellerVO seller);
	int DeleteSellerAccount(String id);
	void UpdateProfileImg(SellerVO account);
	

============================== [ 기석 작업 시작 ] ==============================
	
	public int getOrderRecordOneByIdListCount(String seller_id);
	public List<OrderRecordVO> getOrderRecordOneByIdList(String seller_id, int startrow, int endrow);

============================== [ 기석 작업 끝 ] ==============================


}
