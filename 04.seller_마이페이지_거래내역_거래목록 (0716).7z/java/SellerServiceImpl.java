package com.spring.seller;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mapper.OrderRecordMapper;
import com.spring.mapper.SellerMapper;
import com.spring.order.OrderRecordVO;

@Service
public class SellerServiceImpl implements SellerService {
	@Autowired
	SellerMapper mapper;

============================== [ 기석 작업 시작 ] ==============================

	@Autowired
	OrderRecordMapper orderRecordMapper;

============================== [ 기석 작업 끝 (밑에 계속) ] ==============================

	@Autowired
	private SqlSession sqlSession;

	@Override
	public SellerVO selectOneById(String id) {
		SellerVO sellerAccount = mapper.selectOneById(id);
		return sellerAccount;
	}

	@Override
	public boolean duplicateCheck(String id) {
		int count = mapper.selectCountById(id);
		System.out.println("왜안되냐고~" + count);
		return count == 1 ? true : false;
	}

	@Override
	public void RegisterSellerAccout(SellerVO seller) {
		mapper.InsertSellerAccout(seller);
	}

	@Override
	public int UpdateSellerAccount(SellerVO seller) {
		int isUpdate = mapper.UpdateSellerAccount(seller);
		return isUpdate;
	}

	@Override
	public int DeleteSellerAccount(String id) {
		int isDelete = mapper.DeleteSellerAccount(id);
		return isDelete;
	}

	@Override
	public void UpdateProfileImg(SellerVO account) {
		mapper.UpdateProfileImg(account);

	}



============================== [ 기석 작업 시작 ] ==============================

	@Override
	public int getOrderRecordOneByIdListCount(String seller_id) {
		OrderRecordMapper orderRecordMapper = sqlSession.getMapper(OrderRecordMapper.class);

		int res = orderRecordMapper.getOrderRecordOneByIdListCount(seller_id);
		System.out.println("res : " + res);

		return res;
	}
	
	
	@Override
	public List<OrderRecordVO> getOrderRecordOneByIdList(String seller_id, int startrow, int endrow) {
		
		System.out.println("impl111");
		
		OrderRecordMapper orderRecordMapper = sqlSession.getMapper(OrderRecordMapper.class);
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		map.put("seller_id", seller_id);
		map.put("startrow", startrow);
		map.put("endrow", endrow);
		
		List<OrderRecordVO> vo_list = orderRecordMapper.getOrderRecordOneByIdList(map);
		
		System.out.println("vo_list : " + vo_list);
		
		return vo_list;
	}	

============================== [ 기석 작업 끝 ] ==============================

}
