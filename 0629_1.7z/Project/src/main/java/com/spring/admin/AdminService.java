package com.spring.admin;

public interface AdminService {

}
