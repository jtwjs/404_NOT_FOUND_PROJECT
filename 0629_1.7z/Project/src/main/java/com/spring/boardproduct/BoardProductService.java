package com.spring.boardproduct;

public interface BoardProductService {

}
