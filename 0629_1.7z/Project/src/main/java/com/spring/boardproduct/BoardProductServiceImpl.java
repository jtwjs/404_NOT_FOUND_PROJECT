package com.spring.boardproduct;

import org.springframework.stereotype.Service;

@Service("boardProductService")
public class BoardProductServiceImpl implements BoardProductService {

}
