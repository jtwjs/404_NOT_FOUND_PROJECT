package com.spring.admin;

public interface AdminService {
	boolean duplicateCheck(String id);
}
