package com.spring.boardproduct;

public class BoardProductController {

}
