package com.spring.mapper;

public interface CommentReviewMapper {

}
