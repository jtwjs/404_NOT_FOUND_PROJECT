package com.spring.seller;

public interface SellerService {

}
