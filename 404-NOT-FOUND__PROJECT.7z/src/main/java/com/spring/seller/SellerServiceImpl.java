package com.spring.seller;

import org.springframework.stereotype.Service;

@Service("sellerService")
public class SellerServiceImpl implements SellerService {

}
