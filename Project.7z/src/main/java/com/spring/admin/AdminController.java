package com.spring.admin;

public class AdminController {

}
