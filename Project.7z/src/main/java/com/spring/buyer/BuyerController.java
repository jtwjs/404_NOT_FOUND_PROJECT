package com.spring.buyer;

public class BuyerController {
	


}
