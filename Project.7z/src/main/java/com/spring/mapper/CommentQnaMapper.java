package com.spring.mapper;

public class CommentQnaMapper {

}
