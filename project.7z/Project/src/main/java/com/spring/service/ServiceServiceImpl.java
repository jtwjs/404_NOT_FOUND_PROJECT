package com.spring.service;

import org.springframework.stereotype.Service;

@Service("serviceService")
public class ServiceServiceImpl implements ServiceService {

}
