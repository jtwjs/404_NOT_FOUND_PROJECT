package com.spring.admin;

import org.springframework.stereotype.Service;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

}
