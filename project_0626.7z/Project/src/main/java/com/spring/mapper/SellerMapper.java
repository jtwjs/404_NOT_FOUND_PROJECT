package com.spring.mapper;

public interface SellerMapper {

}
