package com.spring.service;

public interface ServiceService {

}
