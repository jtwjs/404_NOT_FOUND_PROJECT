package com.spring.buyer;

import java.util.ArrayList;
import java.util.HashMap;


public interface BuyerService {

	BuyerVO selectOnById(String id);
	ArrayList<BuyerVO> selectListAll();
	boolean duplicateCheck(String id);
	void RegisterBuyerAccount(BuyerVO buyer);
	int UpdateBuyerAccount(BuyerVO buyer);
	int DeleteBuyerAccount(String id);
    public int getWishListOverlapCheck(String board_id, String buyer_id);
    public int insertWishList(WishListVO vo);
    
    ArrayList<deliveryVO> deliveryListAll(String id);
    
    //배송지부분 시작
    public int InsertListDeliveryList(deliveryVO delivery);
    public deliveryVO getListDeliveryDetail(int num);
    public deliveryVO ListDeliveryModifyForm(int num);
    public int ListDeliveryModify(deliveryVO delivery);
    public int ListDeliveryDelete(HashMap<String, String> hashmap);
    public int UpdateListDeliverList(deliveryVO delivery);
    
    deliveryVO getDefaultAddressOneById(String id);
  //배송지부분 끝
}
