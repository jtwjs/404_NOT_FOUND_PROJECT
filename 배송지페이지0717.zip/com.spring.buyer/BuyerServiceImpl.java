package com.spring.buyer;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mapper.BuyerMapper;

@Service
public class BuyerServiceImpl implements BuyerService {
	
	@Autowired BuyerMapper mapper;
	@Autowired private SqlSession sqlSession;


	
	@Override
	public BuyerVO selectOnById(String id) {
		
		BuyerVO buyerAccount = mapper.selectOneById(id);
		return buyerAccount;
	}
	
	

	@Override
	public void RegisterBuyerAccount(BuyerVO buyer) {
		 mapper.InsertBuyerAccount(buyer);
		
	}

	@Override
	public int UpdateBuyerAccount(BuyerVO buyer) {
		int isUpdate =  mapper.UpdateBuyerAccount(buyer);
		return isUpdate;
	}

	@Override
	public int DeleteBuyerAccount(String id) {
		int isDelete = mapper.DeleteBuyerAccount(id);
		return isDelete;
	}

	@Override
	public boolean duplicateCheck(String id) {
		int count = mapper.selectCountById(id);
		System.out.println("count :" + count);
		
		return count!=0?true:false;
	}



	@Override
	public ArrayList<BuyerVO> selectListAll() {
		ArrayList<BuyerVO> list = mapper.selectListAll();
		return list;
	}

	public int getWishListOverlapCheck(String board_id, String buyer_id) {
		
		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		int result = buyerMapper.getWishListOverlapCheck(board_id, buyer_id);
		
		return result;
	}
	
	public int insertWishList(WishListVO vo) {
		
		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		int result = buyerMapper.insertWishList(vo);
		
		return result;
	}



	@Override
	public ArrayList<deliveryVO> deliveryListAll(String id) {
		ArrayList<deliveryVO> list = mapper.deliveryListAll(id);
		return list;
	}
	
	//배송지페이지 시작
	
	@Override
	public int UpdateListDeliverList(deliveryVO delivery) {
		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		int result = buyerMapper.UpdateListDeliverList(delivery);
		
		return result;
		
	}




	@Override
	public int InsertListDeliveryList(deliveryVO delivery) {
		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);		
		int result = buyerMapper.InsertListDeliveryList(delivery);
		
		delivery.getDefaultaddress();
		
		return result;
		
	}
	

	@Override
	public deliveryVO getListDeliveryDetail(int num) {

		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		deliveryVO delivery = buyerMapper.getListDeliveryDetail(num);
		
		return delivery;
	}

	
	@Override
	public deliveryVO ListDeliveryModifyForm(int num) {

		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		System.out.println(num);
		deliveryVO delivery = buyerMapper.getListDeliveryDetail(num);
		
		return delivery;
	}
	
	
	@Override
	public int ListDeliveryModify(deliveryVO delivery) {

		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		int res = buyerMapper.ListDeliveryModify(delivery);
		
		return res;
	}



	@Override
	public int ListDeliveryDelete(HashMap<String, String> hashmap) {
		BuyerMapper buyerMapper = sqlSession.getMapper(BuyerMapper.class);
		int res = buyerMapper.isListDelivery(hashmap);
		int num = Integer.parseInt(hashmap.get("num"));
		if(res == 1) {
			
			res = buyerMapper.ListDeliveryDelete(num);
		}
		return res;
	}



	@Override
	public deliveryVO getDefaultAddressOneById(String id) {
		
		deliveryVO vo = mapper.getDefaultAddressOneById(id);

		return vo;		
	}	
	
	//배송지페이지 끝
}
