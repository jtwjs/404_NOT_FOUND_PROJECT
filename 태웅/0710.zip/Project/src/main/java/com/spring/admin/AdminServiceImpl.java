package com.spring.admin;

import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

}
