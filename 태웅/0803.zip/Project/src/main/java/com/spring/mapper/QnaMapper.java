package com.spring.mapper;

public interface QnaMapper {

}
