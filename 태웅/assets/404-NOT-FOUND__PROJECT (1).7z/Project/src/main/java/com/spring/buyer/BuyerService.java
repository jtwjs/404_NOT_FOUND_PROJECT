package com.spring.buyer;

public interface BuyerService {

}
