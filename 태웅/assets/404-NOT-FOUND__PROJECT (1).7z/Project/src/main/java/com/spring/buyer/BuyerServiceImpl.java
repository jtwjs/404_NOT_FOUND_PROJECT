package com.spring.buyer;

import org.springframework.stereotype.Service;

@Service("buyerService")
public class BuyerServiceImpl implements BuyerService {

}
