package com.spring.order;

public interface OrderService {

}
